﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace BOPOWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<string>> Get()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["sqlServer"].ConnectionString;
            List<string> result = new List<string>();
            string queryString ="Select * from dbo.userlogin";
            using (SqlConnection connection = new SqlConnection(
            connectionString))
            {
                SqlCommand command = new SqlCommand(
                queryString, connection);
                connection.Open();
                DataTable dt = new DataTable();


                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(Convert.ToString(reader[0]));
                        result.Add(Convert.ToString(reader[1]));
                        result.Add(Convert.ToString(reader[3]));
                    }
                }
            }
            return result;
        }

    }
}
