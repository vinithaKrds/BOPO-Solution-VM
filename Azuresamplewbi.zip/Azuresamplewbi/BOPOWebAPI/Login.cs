﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BOPOWebAPI
{
    public class Login
    {
        public string Username;
        public string Name;
        public string Password;
        public DateTime Createddate;
        public string Createdby;
        public DateTime Updateddate;



    }
}